import { Component } from '@angular/core';

@Component({
  selector: 'app-instructors',
  standalone: false,
  templateUrl: './instructors.component.html',
  styleUrl: './instructors.component.css'
})
export class InstructorsComponent {

  bgImage='instructors_background.jpg';

}
