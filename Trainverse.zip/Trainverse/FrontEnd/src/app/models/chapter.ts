export class Chapter {
    coursename: string = '';
    courseid: string= '';
  
    chapter1name: string = '';
    chapter1id: string = '';
    chapter1description: string = '';
    chapter1videourl: string = '';
    chapter1videoname: string = '';
    chapter1documenturl: string = '';
    chapter1documentname: string = '';
  
    chapter2name: string = '';
    chapter2id: string = '';
    chapter2description: string = '';
    chapter2videourl: string = '';
    chapter2videoname: string = '';
    chapter2documenturl: string = '';
    chapter2documentname: string = '';
  
    chapter3name: string = '';
    chapter3id: string = '';
    chapter3description: string = '';
    chapter3videourl: string = '';
    chapter3videoname: string = '';
    chapter3documenturl: string = '';
    chapter3documentname: string = '';
  
    chapter4name: string = '';
    chapter4id: string = '';
    chapter4description: string = '';
    chapter4videourl: string = '';
    chapter4videoname: string = '';
    chapter4documenturl: string = '';
    chapter4documentname: string = '';
  
    chapter5name: string = '';
    chapter5id: string = '';
    chapter5description: string = '';
    chapter5videourl: string = '';
    chapter5videoname: string = '';
    chapter5documenturl: string = '';
    chapter5documentname: string = '';
  
    constructor() {}
  }
  