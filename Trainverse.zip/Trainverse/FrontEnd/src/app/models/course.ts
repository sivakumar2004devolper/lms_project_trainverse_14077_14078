export class Course {
    coursename: string = '';
    courseid: string = '';
    enrolleddate: string = '';
    instructorname: string = '';
    instructorinstitution: string = '';
    enrolledcount: string = '0';
    youtubeurl: string = '';
    websiteurl: string = '';
    coursetype: string = '';
    skilllevel: string = '';
    language: string = '';
    description: string = '';
    price: string = '';
    rating: string = '';
    about: string = '';
    faq1Question: string = '';
    faq1Answer: string = '';
    faq2Question: string = '';
    faq2Answer: string = '';
    faq3Question: string = '';
    faq3Answer: string = '';
    duration: string = '';
    imageUrl: string = ''
    department : string ='';

    constructor() {}
}

