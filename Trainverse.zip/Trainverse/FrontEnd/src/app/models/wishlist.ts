export class Wishlist {
    coursename : string = '';
    courseid : string = '';
    likeduser : string = '';
    likedusertype : string = '';
    instructorname : string = '';
    instructorinstitution : string = '';
    enrolledcount : string = '0';
    coursetype : string = '';
    websiteurl : string = '';
    skilllevel : string = '';
    language : string = '';
    description : string  = '';

    constructor() {}
}
